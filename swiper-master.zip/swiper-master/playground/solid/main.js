import 'swiper/swiper-bundle.css';

import { render } from 'solid-js/web';

import App from './App.jsx';

// eslint-disable-next-line no-restricted-globals
render(App, document.getElementById('app'));
