export * from './swiper-react.js';
