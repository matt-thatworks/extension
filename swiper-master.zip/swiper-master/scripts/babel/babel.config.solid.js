module.exports = {
  presets: ['solid', ['@babel/preset-env', { modules: false, loose: true }]],
};
